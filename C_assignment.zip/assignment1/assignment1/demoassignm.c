//#include <stdio.h>
//#include <stdlib.h>
//#pragma warning(disable:4996)
//#pragma warning(disable:6031)
//#define A 74.00
//#define B 63.00
//#define C 58.00
//#define D 80.00
//#define E 65.00
//#define F 70.00
//#define DISCOUNT 0.80 //discount 20%
//
//void displayFirstPg();
//void displayMenu();
//void softDevPrgBooks();    //software development programming menu
//void webPrg();             //web programming menu
//void sumRep();             //daily sales order summary report
//
//int count = 0, field, sumqBook, tA, tB, tC, tD, tE, tF;
////field that user need to view   sumqBook=summary quantity of all book   t=qty each book * each price
//int qtyUser, qtyA, qtyB, qtyC, qtyD, qtyE, qtyF, sumA, sumB, sumC, sumD, sumE, sumF;
////qtyUser=qty from user  qty=qty for each book   sum=summary quantity of each book   
//float pA, pB, pC, pD, pE, pF, totalPB, summaryPB;
////p=price for each book same as define   totalPB=total price that user purchased
//char book, confirm, order, pOdr,option;
////book=book that user have selected   confirm=confirm order or not   order=does user need to continue for next order   //pOdr is place order after view menu   option=selection at first page
//
//void main()
//{
//	do {
//		printf("             logo,WELCOME message          \n");
//		printf("                UMT POS SYSTEM             \n");
//		printf("Select an option (1 = View Menu, 2 = Sales Order, 3 = Exit) :");
//		rewind(stdin);
//		scanf("%d", &option); //collect option from user
//
//		switch (option)
//		{
//		case 1:
//			displayMenu();
//			printf("Input :");
//			scanf("%d", &field); //collect field from user
//
//			switch (field)
//			{
//			case 1:
//				softDevPrgBooks();
//				printf("Place an order? (Y=yes N=no):");
//				rewind(stdin);
//				scanf("%c", &pOdr);
//				break;
//
//			case 2:
//				webPrg();
//				printf("Place an order? (Y=yes N=no):");
//				rewind(stdin);
//				scanf("%c", &pOdr);
//				break;
//
//			default:
//				printf("Sorry. Invalid entry please select between 1 or 2 :\n");
//				rewind(stdin);
//				scanf("%d", &field);
//				break;
//			}
//
//			while (pOdr == 'Y')
//			{
//				do
//				{
//					do
//					{
//						printf("Book A, B, C, D, E, F (X = Exit) :\n");
//						rewind(stdin);
//						scanf("%c", &book);
//
//						switch (book)
//						{
//						case 'A':
//							printf("Quantity :");
//							scanf("%d", &qtyUser);
//							qtyA += qtyUser;
//							sumA += qtyA;
//							break;
//
//						case 'B':
//							printf("Quantity :");
//							scanf("%d", &qtyUser);
//							qtyB += qtyUser;
//							sumB += qtyB;
//							break;
//
//						case 'C':
//							printf("Quantity :");
//							scanf("%d", &qtyUser);
//							qtyC += qtyUser;
//							sumC += qtyC;
//							break;
//
//						case 'D':
//							printf("Quantity :");
//							scanf("%d", &qtyUser);
//							qtyD += qtyUser;
//							sumD += qtyD;
//							break;
//
//						case 'E':
//							printf("Quantity :");
//							scanf("%d", &qtyUser);
//							qtyE += qtyUser;
//							sumE += qtyE;
//							break;
//
//						case 'F':
//							printf("Quantity :");
//							scanf("%d", &qtyUser);
//							qtyF += qtyUser;
//							sumF += qtyF;
//							break;
//
//						case 'X':
//							printf("Confirm order ? (Y=yes N=no) :");
//							rewind(stdin);
//							scanf("%c", &confirm);
//							break;
//
//						default:
//							printf("Invalid input");
//						}
//					} while (book != 'X');
//
//					switch (confirm)
//					{
//					case 'Y':
//
//						totalPB = (((qtyA * A) + (qtyB * B) + (qtyC * C) + (qtyD * D) + (qtyE * E) + (qtyF * F)) * DISCOUNT);
//
//						count++;
//						printf("-----------------------------------------------------\n");
//						printf("Number customer :%d\n", count);
//						printf("--BOOK-----QUANTITY-----PRICE_PER_BOOK-----TOTAL_RM--\n");
//						printf("BOOK A      %-d          %-d                %-.2f\n", qtyA, A, qtyA * A);
//						printf("BOOK B      %-d          %-d                %-.2f\n", qtyB, B, qtyB * B);
//						printf("BOOK C      %-d          %-d                %-.2f\n", qtyC, C, qtyC * C);
//						printf("BOOK D      %-d          %-d                %-.2f\n", qtyD, D, qtyD * D);
//						printf("BOOK E      %-d          %-d                %-.2f\n", qtyE, E, qtyE * E);
//						printf("BOOK F      %-d          %-d                %-.2f\n", qtyF, F, qtyF * F);
//						printf("----------------------------------------------------\n");
//						printf("DISCOUNT                                   :%-.2f\n", DISCOUNT);
//						printf("TOTAL                                      :%-.2f\n", totalPB);
//						printf("-----THANK YOU SO MUCH SEE U NEXT TIME !-------------\n");
//						printf("Do you want to continue to next order ?");
//						rewind(stdin);
//						scanf("%c", &order);
//						break;
//
//					case 'N':
//						printf("thanks for using byebye :)");
//						system("pause");
//						break;
//
//					default:
//						printf("Invalid input");
//						break;
//					}
//				} while (order == 'Y');
//
//				while (order == 'N');
//
//				sumqBook = sumA + sumB + sumC + sumD + sumE + sumF;
//				summaryPB = ((sumA * A) + (sumB * B) + (sumC * C) + (sumD * D) + (sumE * E) + (sumF * F));
//
//				printf("\n\t------Daily Sales Order Summary Report------");
//				printf("\n\t-------------Total customer: %d-------------", count);
//				printf("\n\t--Book   \t   Quantity    \t    Amount(RM)--");
//				printf("\n\t  A  \t       %6d  \t           %14.2f", sumA, sumA* A);
//				printf("\n\t  B  \t       %6d  \t           %14.2f", sumB, sumB* B);
//				printf("\n\t  C  \t       %6d  \t           %14.2f", sumC, sumC* C);
//				printf("\n\t  D  \t       %6d  \t           %14.2f", sumA, sumD* D);
//				printf("\n\t  E  \t       %6d  \t           %14.2f", sumB, sumE* E);
//				printf("\n\t  F  \t       %6d  \t           %14.2f", sumC, sumF* F);
//				printf("\n\t============================================");
//				printf("\n\t  Total \t    %6d  \t           %14.2f", sumqBook, summaryPB);
//				break;
//
//			}
//		case 2:
//			displayMenu();
//			printf("Input :");
//			scanf("%d", &field); //collect field from user
//
//			switch (field)
//			{
//			case 1:
//				softDevPrgBooks();
//				printf("Place an order? (Y=yes N=no):");
//				rewind(stdin);
//				scanf("%c", &pOdr);
//				break;
//
//			case 2:
//				webPrg();
//				printf("Place an order? (Y=yes N=no):");
//				rewind(stdin);
//				scanf("%c", &pOdr);
//				break;
//
//			default:
//				printf("Sorry. Invalid entry please select between 1 or 2 :\n");
//				rewind(stdin);
//				scanf("%d", &field);
//				break;
//			}
//
//			while (pOdr == 'Y')
//			{
//				do
//				{
//					do
//					{
//						printf("Book A, B, C, D, E, F (X = Exit) :\n");
//						rewind(stdin);
//						scanf("%c", &book);
//
//						switch (book)
//						{
//						case 'A':
//							printf("Quantity :");
//							scanf("%d", &qtyUser);
//							qtyA += qtyUser;
//							sumA += qtyA;
//							break;
//
//						case 'B':
//							printf("Quantity :");
//							scanf("%d", &qtyUser);
//							qtyB += qtyUser;
//							sumB += qtyB;
//							break;
//
//						case 'C':
//							printf("Quantity :");
//							scanf("%d", &qtyUser);
//							qtyC += qtyUser;
//							sumC += qtyC;
//							break;
//
//						case 'D':
//							printf("Quantity :");
//							scanf("%d", &qtyUser);
//							qtyD += qtyUser;
//							sumD += qtyD;
//							break;
//
//						case 'E':
//							printf("Quantity :");
//							scanf("%d", &qtyUser);
//							qtyE += qtyUser;
//							sumE += qtyE;
//							break;
//
//						case 'F':
//							printf("Quantity :");
//							scanf("%d", &qtyUser);
//							qtyF += qtyUser;
//							sumF += qtyF;
//							break;
//
//						case 'X':
//							printf("Confirm order ? (Y=yes N=no) :");
//							rewind(stdin);
//							scanf("%c", &confirm);
//							break;
//
//						default:
//							printf("Invalid input");
//						}
//					} while (book != 'X');
//
//					switch (confirm)
//					{
//					case 'Y':
//
//						totalPB = (((qtyA * A) + (qtyB * B) + (qtyC * C) + (qtyD * D) + (qtyE * E) + (qtyF * F)) * DISCOUNT);
//
//						count++;
//						printf("-----------------------------------------------------\n");
//						printf("Number customer :%d\n", count);
//						printf("--BOOK-----QUANTITY-----PRICE_PER_BOOK-----TOTAL_RM--\n");
//						printf("BOOK A      %-d          %-d                %-.2f\n", qtyA, A, qtyA * A);
//						printf("BOOK B      %-d          %-d                %-.2f\n", qtyB, B, qtyB * B);
//						printf("BOOK C      %-d          %-d                %-.2f\n", qtyC, C, qtyC * C);
//						printf("BOOK D      %-d          %-d                %-.2f\n", qtyD, D, qtyD * D);
//						printf("BOOK E      %-d          %-d                %-.2f\n", qtyE, E, qtyE * E);
//						printf("BOOK F      %-d          %-d                %-.2f\n", qtyF, F, qtyF * F);
//						printf("----------------------------------------------------\n");
//						printf("DISCOUNT                                   :%-.2f\n", DISCOUNT);
//						printf("TOTAL                                      :%-.2f\n", totalPB);
//						printf("-----THANK YOU SO MUCH SEE U NEXT TIME !-------------\n");
//						printf("Do you want to continue to next order ?");
//						rewind(stdin);
//						scanf("%c", &order);
//						break;
//
//					case 'N':
//						printf("thanks for using byebye :)");
//						system("pause");
//						break;
//
//					default:
//						printf("Invalid input");
//						break;
//					}
//				} while (order == 'Y');
//				break;
//				break;
//
//			case 3:
//				sumqBook = sumA + sumB + sumC + sumD + sumE + sumF;
//				summaryPB = ((sumA * A) + (sumB * B) + (sumC * C) + (sumD * D) + (sumE * E) + (sumF * F));
//
//				printf("\n\t------Daily Sales Order Summary Report------");
//				printf("\n\t-------------Total customer: %d-------------", count);
//				printf("\n\t--Book   \t   Quantity    \t    Amount(RM)--");
//				printf("\n\t  A  \t       %6d  \t           %14.2f", sumA, sumA * A);
//				printf("\n\t  B  \t       %6d  \t           %14.2f", sumB, sumB * B);
//				printf("\n\t  C  \t       %6d  \t           %14.2f", sumC, sumC * C);
//				printf("\n\t  D  \t       %6d  \t           %14.2f", sumA, sumD * D);
//				printf("\n\t  E  \t       %6d  \t           %14.2f", sumB, sumE * E);
//				printf("\n\t  F  \t       %6d  \t           %14.2f", sumC, sumF * F);
//				printf("\n\t============================================");
//				printf("\n\t  Total \t    %6d  \t           %14.2f", sumqBook, summaryPB);
//				break;
//			}
//		}while (order == 'Y');
//
//		system("pause");
//
//	} while (order == 'Y');
//}
//
//	void displayMenu()
//	{
//		printf("\n"); // Print some blank lines
//		printf("Select a field to view:\n"); //menu of books
//		printf("\t1 = Software Development Programming\n");
//		printf("\t2 = Web Programming\n");
//	}
//
//	void softDevPrgBooks() //software deelopment programming books
//	{
//		printf("Software Development Programming Books:\n"
//			"\tA = The Nature of Software Development          RM74.00\n"
//			"\tB = The Art of Computer Programming             RM63.00\n"
//			"\tC = Programming Pearls                          RM58.00\n");
//	}
//
//	void webPrg() //web programming
//	{
//		printf("Web Programing Books :\n"
//			"\tD = HTML and CSS Design                         RM80.00\n"
//			"\tE = Web Programing for Beginners                RM65.00\n"
//			"\tF = Get Coding!                                 RM70.00\n");
//	}
