//#include <stdio.h>
//#include <stdlib.h>
//#include <ctype.h>
//#pragma warning (disable: 4996)
//#pragma warning(disable:6031)
//
//#define DISCOUNT 0.25
//
////global variable declaration
//int count = 0, subA = 0, subB = 0, subC = 0, subD = 0, subE = 0, subF = 0, sumA = 0, sumB = 0, sumC = 0, sumD = 0, sumE = 0, sumF = 0;
//summaryA = 0, summaryB = 0, summaryC = 0, summaryD = 0, summaryE = 0, summaryF = 0;
////sub=quantity that already sold for each book  //sum=total quantity of book that user enter  //summary=summary of each book
//
//float A = 74.00, B = 63.00, C = 58.00, D = 80.00, E = 65.00, F = 70.00, sumPay = 0;
////price for each book
//
//void main() {
//    menu();
//}
//
//int menu()
//{
//    //local variable declaration
//    int  option, field, qtyA = 0, qtyB = 0, qtyC = 0, qtyD = 0, qtyE = 0, qtyF = 0;
//    //qty=quantity of book that user enter
//    char book, confirm, newOrder, SumBack;
//    double totalA, totalB, totalC, totalD, totalE, totalF, discount, subTotal, subPay;
//    //total=qty user enter * price  //subtotal is payment before discout  //subpay is after discount
//
//    do
//    {
//        firstPage();
//        scanf("%d", &option);
//
//
//        //Looping for invalid selection
//        while (option != 1 && option != 2 && option != 3 && option != 4) {
//            printf("\nInvalid option, please enter again (1-4)  :");
//            scanf("%d", &option);
//            rewind(stdin);
//
//
//        }
//
//        switch (option)
//        {
//
//        case 1: //All type of book
//            printf("\nSelect a field to view :\n");
//            printf("\t1 = Software Development Programming\n");
//            printf("\t2 = Web Programming\n");
//            printf("\tfield :");
//            scanf("%d", &field);
//
//            while (field != 1 && field != 2) {           //Looping for invalid selection
//                printf("\nInvalid field . Please enter again (1-2):");
//                scanf("%d", &field);
//                rewind(stdin);
//            }
//
//            switch (field)     //Show Field Following input user
//            {
//            case 1:
//                fieldSwDPB();
//                system("pause");
//                break;
//
//
//            case 2:
//                fieldWPB();
//                system("pause");
//                break;
//            }
//            break;
//
//
//        case 2:
//            do {                                                             // //Loop for new order
//                sumA = 0, sumB = 0, sumC = 0, sumD = 0, sumE = 0, sumF = 0;
//
//                do {
//                    printf("Book A,B,C,D,E,F (X = Exit):");
//                    rewind(stdin);
//                    scanf("%c", &book);
//                    book = toupper(book);
//                    rewind(stdin);
//
//                    switch (book) {
//                    case 'A':
//                        qtyA = QuanA();
//                        rewind(stdin);
//                        sumA += qtyA;
//                        summaryA += qtyA;
//                        break;
//
//                    case 'B':
//                        qtyB = QuanB();
//                        rewind(stdin);
//                        sumB += qtyB;
//                        summaryB += qtyB;
//                        break;
//
//                    case 'C':
//                        qtyC = QuanC();
//                        rewind(stdin);
//                        sumC += qtyC;
//                        summaryC += qtyC;
//                        break;
//
//                    case 'D':
//                        qtyD = QuanD();
//                        rewind(stdin);
//                        sumD += qtyD;
//                        summaryD += qtyD;
//                        break;
//
//                    case 'E':
//                        qtyE = QuanE();
//                        rewind(stdin);
//                        sumE += qtyE;
//                        summaryE += qtyE;
//                        break;
//
//                    case 'F':
//                        qtyF = QuanF();
//                        rewind(stdin);
//                        sumF += qtyF;
//                        summaryF += qtyF;
//                        break;
//
//                    case 'X':
//                        printf("\t----------quit----------\n"); //for exit to place order
//                        break;
//
//                    default:
//                        printf("\t------Invalid Input------\n");
//                    }
//                } while (book != 'X');
//
//                printf("Confirm the order?  (Y=yes N=no):");
//                rewind(stdin);
//                scanf("%c", &confirm);
//                confirm = toupper(confirm);
//                rewind(stdin);
//
//                while (confirm != 'Y' && confirm != 'N')   //Loop for invalid input
//                {
//                    printf("Invalid input please enter again (Y or N):");
//                    scanf("%c", &confirm);
//                    confirm = toupper(confirm);
//                    rewind(stdin);
//                }
//                switch (confirm)
//                {
//                case 'Y':     //confirm order
//                    count++; //add num customer
//                    totalA = sumA * A;      //Total price for each type of book 
//                    totalB = sumB * B;
//                    totalC = sumC * C;
//                    totalD = sumD * D;
//                    totalE = sumE * E;
//                    totalF = sumF * F;
//
//                    subTotal = totalA + totalB + totalC + totalD + totalE + totalF;     //Total price for all book
//
//                    subA += sumA;   //Proses for summary 
//                    subB += sumB;
//                    subC += sumC;
//                    subD += sumD;
//                    subE += sumE;
//                    subF += sumF;
//
//                    discount = subTotal * DISCOUNT;
//                    subPay = subTotal - discount;
//
//                    sumPay += subTotal;
//                    //receipt
//                    printf("Customer Number :%d\n", count);
//                    printf("------------------------------------------------------------------------\n");
//                    printf("BOOK    QUANTITY   PRICE_PER_BOOK                       TOTAL:          \n");
//                    printf("------------------------------------------------------------------------\n");
//                    printf("book A: %3d @      RM%3.2f                             = RM%4.2f\n", sumA, A, totalA);
//                    printf("book B: %3d @      RM%3.2f                             = RM%4.2f\n", sumB, B, totalB);
//                    printf("book C: %3d @      RM%3.2f                             = RM%4.2f\n", sumC, C, totalC);
//                    printf("book D: %3d @      RM%3.2f                             = RM%4.2f\n", sumD, D, totalD);
//                    printf("book E: %3d @      RM%3.2f                             = RM%4.2f\n", sumE, E, totalE);
//                    printf("book F: %3d @      RM%3.2f                             = RM%4.2f\n", sumF, F, totalF);
//                    printf("                                                    ====================\n");
//                    printf("Subtotal                                               = RM%4.2f\n", subTotal);
//                    printf("Discount                                               = RM%4.2f\n", discount);
//                    printf("                                                    ====================\n");
//                    printf("Total                                                  = RM%4.2f\n", subPay);
//                    printf("                                                    ====================\n");
//                    printf("\n\tThank you see u next time! ");
//                    printf("\n\n\tNext order? (Y=yes  N=no):");
//                    scanf("%c", &newOrder); //new order
//                    newOrder = toupper(newOrder);
//                    rewind(stdin);
//
//                    while (newOrder != 'Y' && newOrder != 'N')     //Loop for invalid input
//                    {
//                        printf("Invalid input please enter again (Y / N) :");
//                        rewind(stdin);
//                        scanf("%c", &newOrder);
//                        newOrder = toupper(newOrder);
//                    }
//                    break;
//
//                case 'N':
//                    //cancle order
//                    summaryA -= sumA;      //decrease the book that user already cancel
//                    summaryB -= sumB;
//                    summaryC -= sumC;
//                    summaryD -= sumD;
//                    summaryF -= sumF;
//
//                    menu();
//                    break;
//                }
//            } while (newOrder == 'Y');
//            rewind(stdin);
//            menu();   //run menu 
//
//        case 3:
//            summary();     //run summary
//            printf("\n\n\t\tBack to Menu? (Y = Yes , E = Exit) :");
//            rewind(stdin);
//            scanf("%c", &SumBack);
//            SumBack = toupper(SumBack);
//
//            while (SumBack != 'Y' && SumBack != 'E') {                  //loop for invalid input
//                printf("\n\tInvalid, Please try again(Y = Yes , E = Exit) :");
//                rewind(stdin);
//                scanf("%c", &SumBack);
//                SumBack = toupper(SumBack);
//            }
//            switch (SumBack)
//            {
//            case 'Y':
//                menu();
//                break;
//
//            case 'E':
//                exit(0);  //exit program
//                break;
//            }
//            break;
//
//        case 4:
//            exit(0);   //exit program
//            break;
//        }
//    } while (option != 4);
//}
//
//int firstPage() {
//    printf("             logo,WELCOME message          \n");
//    printf("                UMT POS SYSTEM             \n");
//    printf("Select an option (1 = View Menu, 2 = Sales Order,3 = Summary, 4 = Exit) :");
//}
//
//int fieldSwDPB() {
//    printf("Software Development Programming Books:\n"
//        "\tA = The Nature of Software Development          RM74.00\n"
//        "\tB = The Art of Computer Programming             RM63.00\n"
//        "\tC = Programming Pearls                          RM58.00\n");
//}
//
//int fieldWPB() {
//    printf("Web Programing Books :\n"
//        "\tD = HTML and CSS Design                         RM80.00\n"
//        "\tE = Web Programing for Beginners                RM65.00\n"
//        "\tF = Get Coding!                                 RM70.00\n");
//}
//
//int QuanA() {
//    int qtyA;
//    char row;
//
//    printf("\t\tQuantity BOOK A:");
//    rewind(stdin);
//    while (scanf("%d%c", &qtyA, &row) != 2 || row != '\n') {
//        printf("\t\t------Invalid Input------\n");
//        printf("\n\t\tQuantity BOOK A:");
//        scanf("%d%c", &qtyA, &row);
//        rewind(stdin);
//    }
//    return qtyA;
//}
//
//int QuanB() {
//    int qtyB;
//    char row;
//
//    printf("\t\tQuantity BOOK B:");
//    rewind(stdin);
//    while (scanf("%d%c", &qtyB, &row) != 2 || row != '\n') {
//        printf("\t\t------Invalid Input------\n");
//        printf("\n\t\tQuantity BOOK B:");
//        scanf("%d%c", &qtyB, &row);
//        rewind(stdin);
//    }
//    return qtyB;
//}
//
//int QuanC() {
//    int qtyC;
//    char row;
//
//    printf("\t\tQuantity BOOK C:");
//    rewind(stdin);
//    while (scanf("%d%c", &qtyC, &row) != 2 || row != '\n') {
//        printf("\t\t------Invalid Input------\n");
//        printf("\n\t\tQuantity BOOK C:");
//        scanf("%d%c", &qtyC, &row);
//        rewind(stdin);
//    }
//    return qtyC;
//}
//
//int QuanD() {
//    int qtyD;
//    char row;
//
//    printf("\t\tQuantity BOOK D:");
//    rewind(stdin);
//    while (scanf("%d%c", &qtyD, &row) != 2 || row != '\n') {
//        printf("\t\t------Invalid Input------\n");
//        printf("\n\t\tQuantity BOOK D:");
//        scanf("%d%c", &qtyD, &row);
//        rewind(stdin);
//    }
//    return qtyD;
//}
//
//int QuanE() {
//    int qtyE;
//    char row;
//
//    printf("\t\tQuantity of BOOK E:");
//    rewind(stdin);
//    while (scanf("%d%c", &qtyE, &row) != 2 || row != '\n') {
//        printf("\t\t------Invalid Input------\n");
//        printf("\n\t\tQuantity BOOK E:");
//        scanf("%d%c", &qtyE, &row);
//        rewind(stdin);
//    }
//    return qtyE;
//}
//
//int QuanF() {
//    int qtyF;
//    char row;
//
//
//    printf("\t\tQuantity of BOOK F:");
//    rewind(stdin);
//    while (scanf("%d%c", &qtyF, &row) != 2 || row != '\n') {
//        printf("\t\t------Invalid Input------\n");
//        printf("\n\t\tQuantity BOOK F:");
//        scanf("%d%c", &qtyF, &row);
//        rewind(stdin);
//    }
//    return qtyF;
//}
//
//int summary() {
//    //local variable declaration
//    int subBook;
//    double subTotal, totalA, totalB, totalC, totalD, totalE, totalF;
//    //total price for each book
//    totalA = summaryA * A;
//    totalB = summaryB * B;
//    totalC = summaryC * C;
//    totalD = summaryD * D;
//    totalE = summaryE * E;
//    totalF = summaryF * F;
//
//    //quantity for all book
//    subBook = subA + subB + subC + subD + subE + subF;
//    subTotal = totalA + totalB + totalC + totalD + totalE + totalF;
//
//    //Summary Report
//    printf("\n\t---------------------------------------\n");
//    printf("\n\t Daily Sales Order Summary Report");
//    printf("\n\t Total customer: %d", count);
//    printf("\n\t---------------------------------------\n");
//    printf("\n\tBOOK   \t   QUANTITY    \t    TOTAL(RM)");
//    printf("\n\t---------------------------------------\n");
//    printf("\n\tA  \t  %6d  \t  %14.2f", subA, totalA);
//    printf("\n\tB  \t  %6d  \t  %14.2f", subB, totalB);
//    printf("\n\tC  \t  %6d  \t  %14.2f", subC, totalC);
//    printf("\n\tD  \t  %6d  \t  %14.2f", subD, totalD);
//    printf("\n\tE  \t  %6d  \t  %14.2f", subE, totalE);
//    printf("\n\tF  \t  %6d  \t  %14.2f", subF, totalF);
//    printf("\n\t========================================");
//    printf("\n\tTotal \t  %6d  \t  %14.2f", subBook, subTotal);
//}